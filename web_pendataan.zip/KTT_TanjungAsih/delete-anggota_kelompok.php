<?php
include("koneksi.php");
if (isset($_GET['no_anggota'])) {
	$id = $_GET['no_anggota'];
	$delSql = mysqli_query($db, "DELETE FROM anggota_kelompok WHERE no_anggota = '$id'");
	if ($delSql) {
		header('Location: data-anggota_kelompok.php');
	}
}
else header('location: 404.html');
?>