<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Login - KTT Tanjung Asih</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body class="img js-fullheight" style="background-image: url(img/bg.jpg); background-size: cover;">

  <div class="container">
<br><br><br><br><br><br><br><br><br>
    <!-- Outer Row -->
    
    <div class="row justify-content-center">

      <div class="col-md-offset-4 col-md-4 col-sm-offset-3 col-sm-6">
                  <div class="text-center">
                    </div>
                  <form class="user" method="post">
                    <div class="form-group">
                      <input type="text" class="form-control form-control-user" id="exampleInputUsername" aria-describedby="usernameHelp" name="username" placeholder="Username">
                    </div>
                    <div class="form-group">
                      <input type="password" class="form-control form-control-user" id="exampleInputPassword" name="pass" placeholder="Password">
                    </div>
          <input type="submit" class="btn btn-info btn-user btn-block" name="login" value="Login"/>
                  </form>
				  <?php
				  include("koneksi.php");
				  session_start();
				  if (isset($_SESSION['username'])) {
					header("location: dashboard.php");
				  }
				  if (isset($_POST['username']) && isset($_POST['pass'])) {
					  $username = $_POST['username'];
					  $pass = $_POST['pass'];
					  
					  $sql = mysqli_query($db, "SELECT * FROM `account` WHERE `username` = '$username' AND `password` = '$pass'");
					  $cek = mysqli_num_rows($sql);
					  if ($cek > 0) {
						  while ($user = mysqli_fetch_array($sql)) {
							  $_SESSION['username'] = $user['username'];
							  $_SESSION['status'] = $user['status'];
						  }
						  header("location: dashboard.php");
					  }
				  }
				  ?>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>

  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>
</body>

</html>
