<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Tambah Populasi Sapi - KTT Tanjung Asih</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
  <?php
  include("koneksi.php");
  session_start();
  ?>
</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <?php include("sidebar.php"); ?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <?php include("topBar.php"); ?>

        </nav>
        <!-- End of Topbar -->
	  <!-- Content Row -->
          <div class="container-fluid">
			<div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Tambah Produksi Olahan Kelompok Tani Ternak Tanjung Asih</h6>
            </div>
            <div class="card-body">
				<?php
				if (isset($_GET['id_a'])){
					$id = $_GET['id_a'];
					$cekId = mysqli_query($db, "SELECT * FROM produksi_olahan WHERE id_a = '$id'");
					if (mysqli_num_rows($cekId) > 0) {
						while ($edit = mysqli_fetch_array($cekId)) {
				?>
				<form action="" id="tambahProduksi" method="post">
					<b>No</b>:<br/>
					<input type="number" class="form-control form-control-user" name="id_a" value="<?php echo $edit['id_a']; ?>" required><br/>
					<b>Hari</b>:<br/>
					<input type="text" class="form-control form-control-user" name="hari" value="<?php echo $edit['hari']; ?>" required><br/>
					<b>Tanggal</b>:<br/>
					<input type="text" class="form-control form-control-user" name="tanggal" value="<?php echo $edit['tanggal']; ?>" required><br/>
					<b>Produksi</b>:<br/>
					<input type="text" class="form-control form-control-user" name="produksi" value="<?php echo $edit['produksi']; ?>" required /><br/>
					
					
					<button type="submit" class="btn btn-primary btn-icon-split btn-sm">
						<span class="icon text-white-100">
						  <i class="fas fa-plus"></i>
						</span>
						<span class="text">Edit</span>
					</button>
				</form>
				<?php
						}
					}
				}
				if (isset($_POST['id_a'])) {
					$id_a = $_POST['id_a'];
					$hari = $_POST['hari'];
					$tanggal = $_POST['tanggal'];
					$produksi = $_POST['produksi']
					
					$insertSql = mysqli_query($db, "UPDATE produksi_olahan SET id_a = '$id_a', hari = '$hari', tanggal = '$tanggal', produksi = '$produksi' WHERE no_ang = '$id'");
					if ($insertSql) {
						echo '<meta http-equiv="refresh" content="0;url=data-produksi_olahan.php">';
					}
				}
				?>
			</div>
			</div>
		  </div>
        </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; KTT Tanjung Asih 2022 </span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
  
  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

</body>

</html>
