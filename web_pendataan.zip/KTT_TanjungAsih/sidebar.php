	<!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-info sidebar sidebar-dark accordion" id="accordionSidebar">
	<?php
	$curPageName = substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);
	?>
      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard.php">
        <div class="sidebar-brand-icon rotate-n-15">
        </div>
        <div class="sidebar-brand-text mx-3">Tanjung Asih</div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
	  
      <li class="nav-item <?php if ($curPageName == "dashboard.php") echo "active"; ?>">
        <a class="nav-link" href="dashboard.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Jadwal Kegiatan</span></a>
      </li>
	  <?php
	  if ($_SESSION['status'] == "admin") {
		?>
	  <li class="nav-item <?php if ($curPageName == "tambah-peternak.php") echo "active"; ?>">
        <a class="nav-link" href="tambah-peternak.php">
          <i class="fas fa-plus"></i>
          <span>Tambah Peternak</span></a>
      </li>
		<?php
	  }
	  ?>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Data
      </div>

      <!-- Nav Item - Pages Collapse Menu -->
      <?php
    if ($_SESSION['status'] == "admin") {
    ?>
      <li class="nav-item <?php if ($curPageName == "tambah-anggota_kelompok.php") echo "active"; ?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
          <i class="fas fa-plus"></i>
          <span>Tambah</span>
        </a>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Kategori:</h6>
            <a class="collapse-item" href="tambah-anggota_kelompok.php">Tambah Data Anggota</a>
            <a class="collapse-item" href="tambah-populasi_sapi.php">Tambah Populasi Sapi</a>
            <a class="collapse-item" href="tambah-produksi_susu.php">Tambah Produksi Susu</a>
            <a class="collapse-item" href="tambah-produksi_olahan.php">Tambah Produksi Olahan</a>
        </div>
      </li>
	  <?php
    }
    ?>
	  <li class="nav-item <?php if ($curPageName == "data-anggota.php") echo "active"; ?>">
        <a class="nav-link" href="data-anggota_kelompok.php">
          <span>Data Anggota Kelompok</span></a>

          <a class="nav-link" href="data-populasi_sapi.php">
          </i><span>Data Populasi Sapi</span></a>

          <a class="nav-link" href="data-produksi_susu.php">         
          <span>Data Produksi Susu</span></a>

          <a class="nav-link" href="data-produksi_olahan.php">
          <span>Data Produksi Olahan</span></a>
      </li>
	  

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->