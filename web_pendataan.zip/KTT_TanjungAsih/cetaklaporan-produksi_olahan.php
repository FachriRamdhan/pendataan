<?php
session_start();
if(!isset($_SESSION['username'])){
    echo "<script>location.href='login.php'</script>";
}
 
?>
<?php
 //KONEKSI
$host="localhost"; //isi dengan host anda. contoh "localhost"
$user="root"; //isi dengan username mysql anda. contoh "root"
$password=""; //isi dengan password mysql anda. jika tidak ada, biarkan kosong.
$database="tani";//isi nama database dengan tepat.
$konek = mysqli_connect($host,$user,$password,$database);
?>

<style type="text/css">
p{
    text-align:right;
    font-style:bold;
    font-size:12px
}
h4, h1, h5, h2{
    text-align:center;
    padding-top:inherit;
    
}
table {
   border-collapse:collapse;
   width:100%;
}
 
table, td, th {
   border:1px solid black;
}
 
tbody tr:nth-child(odd) {
   background-color: #ccc;
}
</style>
<h2>Kelompok Tani Ternak Tanjung Asih</h2>
<h5>Kampung Panaruban, Desa Cicadas, Sagalaherang, Subang, Jawa Barat.</h5>
<hr>

</tr>
</table>
<h4>LAPORAN PRODUKSI OLAHAN per bulan</h4>


<table >
<thead>
<tr>
<th>No</th>
<th>Hari</td>
<th>Tanggal</td>
<th>Produksi</td>


</tr>
</thead>
<?php 
$sql=mysqli_query($konek,"SELECT * FROM produksi_olahan ORDER BY id_a ASC");
while($data=mysqli_fetch_array($sql)){
?>
<tbody><tr>
<td><?php echo $data['no']?></td>
<td><?php echo $data['hari']?></td>
<td><?php echo $data['tanggal']?></td>
<td><?php echo $data['produksi']?></td>


</tr></tbody>
<?php
}
?>
</table>
    <script>
        window.print();
    </script>
