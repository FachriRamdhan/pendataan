<?php
include("koneksi.php");
if (isset($_GET['id_ang'])) {
	$id = $_GET['id_ang'];
	$delSql = mysqli_query($db, "DELETE FROM produksi_susu WHERE id_ang = '$id'");
	if ($delSql) {
		header('Location: dashboard.php');
	}
}
else header('location: 404.html');
?>