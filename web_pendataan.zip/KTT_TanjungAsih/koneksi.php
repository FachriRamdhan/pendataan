<?php
   $hostname  = "localhost";
   $username  = "root";
   $pass  = "";
   $database  = "tani";
   $db = new mysqli($hostname, $username, $pass, $database);
?>