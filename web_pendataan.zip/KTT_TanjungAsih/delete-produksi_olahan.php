<?php
include("koneksi.php");
if (isset($_GET['id_a'])) {
	$id = $_GET['id_a'];
	$delSql = mysqli_query($db, "DELETE FROM produksi_olahan WHERE id_a = '$id'");
	if ($delSql) {
		header('Location: dashboard.php');
	}
}
else header('location: 404.html');
?>