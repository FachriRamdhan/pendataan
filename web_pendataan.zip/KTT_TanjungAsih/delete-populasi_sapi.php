<?php
include("koneksi.php");
if (isset($_GET['no_ang'])) {
	$id = $_GET['no_ang'];
	$delSql = mysqli_query($db, "DELETE FROM populasi_sapi WHERE no_ang = '$id'");
	if ($delSql) {
		header('Location: dashboard.php');
	}
}
else header('location: 404.html');
?>