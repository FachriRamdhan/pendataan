-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 01 Feb 2022 pada 15.42
-- Versi server: 10.4.21-MariaDB
-- Versi PHP: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tani`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `account`
--

CREATE TABLE `account` (
  `username` varchar(12) NOT NULL,
  `password` varchar(12) NOT NULL,
  `nama` text NOT NULL,
  `alamat` text NOT NULL,
  `no_hp` varchar(13) NOT NULL,
  `status` enum('peternak','admin','user') NOT NULL DEFAULT 'peternak',
  `pendidikan` text NOT NULL,
  `gambar` varchar(255) NOT NULL DEFAULT 'default.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `account`
--

INSERT INTO `account` (`username`, `password`, `nama`, `alamat`, `no_hp`, `status`, `pendidikan`, `gambar`) VALUES
('admin', 'admin', 'Fachri Ramdhan', '-', '-', 'admin', '-', 'default.png'),
('user', 'user', 'Ela Maesaroh', 'Kampung Panaruban', '081238378', 'peternak', 'SMEA', 'default.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `anggota_kelompok`
--

CREATE TABLE `anggota_kelompok` (
  `no_anggota` varchar(16) NOT NULL,
  `nama` text NOT NULL,
  `gender` enum('Laki-Laki','Perempuan') NOT NULL,
  `alamat` text NOT NULL,
  `lahan` text NOT NULL,
  `kandang` varchar(3) NOT NULL,
  `ternak` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `anggota_kelompok`
--

INSERT INTO `anggota_kelompok` (`no_anggota`, `nama`, `gender`, `alamat`, `lahan`, `kandang`, `ternak`) VALUES
('0001', 'Wiwi Hasanah', 'Laki-Laki', 'KP. Panaruban', '-', '-', '-'),
('0002', 'Ita Suhenda', 'Perempuan', 'KP. Panaruban', '-', '-', '-'),
('0003', 'Ela Maesaroh', 'Perempuan', 'KP. Panaruban', '-', '-', '-'),
('0004', 'Anang', 'Laki-Laki', 'KP. Panaruban', '1.500m', '50m', '4'),
('0005', 'Olih', 'Laki-Laki', 'KP. Panaruban', '800m', '50m', '4'),
('0006', 'Ecep A', 'Laki-Laki', 'KP. Panaruban', '1000m', '28m', '4'),
('0007', 'Arsih', 'Perempuan', 'Kp.panaruban', '800m', '30m', '3'),
('0008', 'Emin', 'Laki-Laki', 'Kp.panaruban', '500m', '25m', '3'),
('0009', 'Emo', 'Laki-Laki', 'Kp.panaruban', '1500m', '20m', '3'),
('0010', 'Tisnawati', 'Perempuan', 'Kp.panaruban', '500m', '40m', '1'),
('0011', 'Maman A', 'Laki-Laki', 'Kp.panaruban', '500m', '15m', '2'),
('0012', 'Kardi', 'Laki-Laki', 'Kp.panaruban', '1000m', '25m', '3');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jadwal_kegiatan`
--

CREATE TABLE `jadwal_kegiatan` (
  `id_jadwal` varchar(16) NOT NULL,
  `tanggal` date NOT NULL,
  `pukul` varchar(6) NOT NULL,
  `kegiatan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `jadwal_kegiatan`
--

INSERT INTO `jadwal_kegiatan` (`id_jadwal`, `tanggal`, `pukul`, `kegiatan`) VALUES
('K19012022022826', '2014-01-19', '09.00', 'penyuluhuan teknis sapi perah dan penanggulan ternak'),
('K19012022022918', '2014-01-24', '09.00', 'Demo membuat silase jerami'),
('K19012022023000', '2014-02-07', '09:00', 'membuka hasil membuat siage'),
('K19012022023119', '2014-03-14', '02:30', 'diskusi program ke anggota'),
('K19012022023219', '2022-03-20', '12:00', 'diskusi tentang manfaa bikin silase untuk ternak ke anggota'),
('K19012022023316', '2014-04-23', '09:00', 'menghadiri rapat ke KPSBU Lembang bersama anggota'),
('K19012022023352', '2014-12-09', '09:00', 'menghadiri acara penutupan program DDCP'),
('K19012022023452', '2015-06-20', '09:00', 'Penanaman rumput, gajah, kaliandra putih'),
('K19012022023531', '2015-06-18', '02:34', 'Pelatihan penanaman rumput benggala dan lantoro'),
('K19012022023615', '2016-01-22', '09:00', 'pelatihan membuat silase jerami'),
('K19012022023652', '2016-01-30', '09:00', 'Latihan membuat pupuk organik dan kotoran sapi'),
('K19012022023739', '2016-10-30', '09:00', 'Penyuluhan manfaat biogas bagi para peternak'),
('K19012022023850', '2017-01-31', '09:00', 'Pelatihan menanam pohon logium'),
('K19012022023928', '2017-11-23', '09:00', 'Penyuluhan membuat penampungan susu');

-- --------------------------------------------------------

--
-- Struktur dari tabel `populasi_sapi`
--

CREATE TABLE `populasi_sapi` (
  `no_ang` varchar(16) NOT NULL,
  `nama` text NOT NULL,
  `tanggal` text NOT NULL,
  `lokasi` text NOT NULL,
  `dara` text NOT NULL,
  `pedet` text NOT NULL,
  `induk` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `populasi_sapi`
--

INSERT INTO `populasi_sapi` (`no_ang`, `nama`, `tanggal`, `lokasi`, `dara`, `pedet`, `induk`) VALUES
('1', 'Anang B Ondi', '1 Mei 2019', 'Kandang Sendiri', '-', '1', '-'),
('10', 'Tri Mumpuni', '1 Mei 2019', 'Kandang Sendiri', '-', '1', '3'),
('11', 'Dedi Mulyadi', '1 Mei 2019', 'Kandang Sendiri', '-', '-', '2'),
('12', 'Maman', '1 Mei 2019', 'Kandang Sendiri', '-', '-', '1'),
('13', 'Ano B ace', '1 Mei 2019', 'Kandang Sendiri', '-', '-', '2'),
('14', 'Edi Ardianto', '1 Mei 2019', 'Kandang Sendiri', '-', '-', '1'),
('15', 'Alan Cahya', '1 Mei 2019', 'Kandang Sendiri', '-', '-', '2'),
('16', 'Ita Rosidi', '1 Mei 2019', 'Kandang Sendiri', '-', '-', '2'),
('17', 'Ukin B ace', '1 Mei 2019', 'Kandang Sendiri', '-', '-', '2'),
('18', 'Isak B andi', '1 Mei 2019', 'Kandang Sendiri', '-', '-', '2'),
('19', 'Agus Hendrik', '1 Mei 2019', 'Kandang Sendiri', '-', '1', '2'),
('2', 'Olih B Ukin', '1 Mei 2019', 'Kandang Sendiri', '-', '1', '2'),
('20', 'Asep Suhana', '1 Mei 2019', 'Kandang Sendiri', '-', '-', '2'),
('21', 'Usep Sudomo', '1 Mei 2019', 'Kandang Sendiri', '-', '-', '1'),
('22', 'Ijen Jaelani', '1 Mei 2019', 'Kandang Sendiri', '-', '-', '2'),
('23', 'Usman', '1 Mei 2019', 'Kandang Sendiri', '1', '-', '--'),
('24', 'Rano', '1 Mei 2019', 'Kandang Sendiri', '-', '-', '-'),
('25', 'Wiwi Hasanah', '1 Mei 2019', 'Kandang Sendiri', '--', '-', '-'),
('26', 'Ela Maesaroh', '1 Mei 2019', 'Kandang Sendiri', '-', '-', '-'),
('27', 'Ita Suhenda', '1 Mei 2019', 'Kandang Sendiri', '-', '-', '-'),
('3', 'Arcih', '1 Mei 2019', 'Kandang Sendiri', '-', '1', '1'),
('4', 'Ecep Amruloh', '1 Mei 2019', 'Kandang Sendiri', '-', '1', '2'),
('5', 'Min Uco', '1 Mei 2019', 'Kandang Sendiri', '-', '-', '1'),
('6', 'Emo', '1 Mei 2019', 'Kandang Sendiri', '-', '-', '1'),
('7', 'Trisnawati', '1 Mei 2019', 'Kandang Sendiri', '-', '-', '1'),
('8', 'Maman A', '1 Mei 2019', 'Kandang Sendiri', '-', '-', '-'),
('9', 'Kardi', '1 Mei 2019', 'Kandang Sendiri', '-', '-', '1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `produksi_olahan`
--

CREATE TABLE `produksi_olahan` (
  `id_a` varchar(16) NOT NULL,
  `hari` text NOT NULL,
  `tanggal` text NOT NULL,
  `produksi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `produksi_olahan`
--

INSERT INTO `produksi_olahan` (`id_a`, `hari`, `tanggal`, `produksi`) VALUES
('1', 'Senin', '22 Januari 2018', '-'),
('10', 'Senin', '22 Januari 2018', '-'),
('11', 'Senin', '22 Januari 2018', '-'),
('12', 'Senin', '22 Januari 2018', '-'),
('2', 'Senin', '22 Januari 2018', '-'),
('3', 'Senin', '22 Januari 2018', '-'),
('4', 'Senin', '22 Januari 2018', '-'),
('5', 'Senin', '22 Januari 2018', '-'),
('6', 'Senin', '22 Januari 2018', '-'),
('7', 'Senin', '22 Januari 2018', '-'),
('8', 'Senin', '22 Januari 2018', '-'),
('9', 'Senin', '22 Januari 2018', '-'),;

-- --------------------------------------------------------

--
-- Struktur dari tabel `produksi_susu`
--

CREATE TABLE `produksi_susu` (
  `id_ang` varchar(16) NOT NULL,
  `nama` text NOT NULL,
  `tanggal` text NOT NULL,
  `hari` text NOT NULL,
  `ternak` text NOT NULL,
  `susu` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `produksi_susu`
--

INSERT INTO `produksi_susu` (`id_ang`, `nama`, `tanggal`, `hari`, `ternak`, `susu`) VALUES
('1', 'Anang B Ondi', '1 Mei 2015', 'Senin', '3 ekor', '26/ltr'),
('10', 'Tri Mumpuni', '1 Mei 2015', 'Senin', '3 ekor', '26/ltr'),
('12', 'Dedi Mulyadi', '1 Mei 2015', 'Senin', '3 ekor', '26/ltr'),
('2', 'Olih B Ukin', '1 Mei 2015', 'Senin', '3 ekor', '26/ltr'),
('3', 'Arcih', '1 Mei 2015', 'Senin', '3 ekor', '26/ltr'),
('4', 'Ecep Amruloh', '1 Mei 2015', 'Senin', '3 ekor', '26/ltr'),
('6', 'Emo', '1 Mei 2015', 'Senin', '3 ekor', '26/ltr'),
('7', 'Trisnawati', '1 Mei 2015', 'Senin', '3 ekor', '26/ltr'),
('8', 'Maman A', '1 Mei 2015', 'Senin', '3 ekor', '26/ltr'),
('9', 'Kardi', '1 Mei 2015', 'Senin', '3 ekor', '26/ltr'),;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`username`);

--
-- Indeks untuk tabel `anggota_kelompok`
--
ALTER TABLE `anggota_kelompok`
  ADD PRIMARY KEY (`no_anggota`);

--
-- Indeks untuk tabel `jadwal_kegiatan`
--
ALTER TABLE `jadwal_kegiatan`
  ADD PRIMARY KEY (`id_jadwal`);

--
-- Indeks untuk tabel `populasi_sapi`
--
ALTER TABLE `populasi_sapi`
  ADD PRIMARY KEY (`no_ang`);

--
-- Indeks untuk tabel `produksi_olahan`
--
ALTER TABLE `produksi_olahan`
  ADD PRIMARY KEY (`id_a`);

--
-- Indeks untuk tabel `produksi_susu`
--
ALTER TABLE `produksi_susu`
  ADD PRIMARY KEY (`id_ang`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
